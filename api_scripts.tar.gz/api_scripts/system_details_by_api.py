import flask
import socket
from flask import request

obj_flask = flask.Flask(__name__)
obj_flask.config["DEBUG"] = True


@obj_flask.route("/cmd_system_ip", methods=["GET"])
def system_ip():
    system_details = {}
    system_details['hostname'] = socket.gethostname()

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    system_details['ip_address'] = s.getsockname()[0]
    s.close()
    return system_details,200

@obj_flask.route("/cmd_update_file_in_linux", methods=["POST"])
def update_data():
    print("Inside post method")

    data = request.get_json()
    print(data)
    return data




obj_flask.run(host='192.168.29.112', port=9966)
